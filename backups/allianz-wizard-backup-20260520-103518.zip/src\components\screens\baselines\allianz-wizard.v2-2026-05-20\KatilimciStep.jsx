import { useState } from 'react'
import { Search, Plus } from 'lucide-react'
import IkametgahAdresModal, { formatIkametgahOzet, ikametgahFromForm } from '../allianz/IkametgahAdresModal'

const KIMLIK_TURLERI = [
  'NÜFUS CÜZDANI',
  'Ehliyet',
  'Evlilik Cüzdanı',
  'Nüfus Kayıt Örneği',
  'Pasaport',
  'Diğer',
]

const EGITIM_OPTIONS = ['İLKOKUL', 'ORTAOKUL', 'LİSE', 'ÜNİVERSİTE', 'YÜKSEK LİSANS', 'DOKTORA']
const GELIR_OPTIONS = ['0-150', '150-750', '750-1500', '1500+']
const MESLEK_OPTIONS = ['ACENTE', 'MÜHENDİS', 'DOKTOR', 'ÖĞRETMEN', 'MEMUR']
const ULKE_OPTIONS = ['TÜRKİYE', 'ALMANYA', 'ABD', 'İNGİLTERE']

function DetayBaslik({ children }) {
  return (
    <div className="bg-slate-100 border border-slate-200 border-b-0 px-4 py-2.5 mt-6 first:mt-0">
      <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wide">{children}</h4>
    </div>
  )
}

function DetayPanel({ children }) {
  return <div className="border border-slate-200 border-t-0 rounded-b-lg p-4 md:p-5 bg-white">{children}</div>
}

function ZorunluUyari() {
  return <p className="text-[11px] text-red-600 font-semibold mt-1">⚠ Zorunlu alan!</p>
}

function UnderlineField({ label, required, children, hint }) {
  return (
    <div className="space-y-1 min-w-0">
      <label className={`text-xs font-bold uppercase ${required ? 'text-red-600' : 'text-slate-600'}`}>{label}</label>
      {children}
      {hint}
    </div>
  )
}

function EvetHayirGroup({ label, name, value, onChange, required }) {
  return (
    <div className="space-y-1">
      <label className={`text-xs font-bold uppercase ${required ? 'text-red-600' : 'text-slate-600'}`}>{label}</label>
      <div className="flex gap-6 pt-1">
        {['Evet', 'Hayır'].map((v) => (
          <label key={v} className="flex items-center gap-2 text-sm font-semibold cursor-pointer">
            <input type="radio" name={name} checked={value === v} onChange={() => onChange(v)} className="w-4 h-4 text-blue-600" />
            {v}
          </label>
        ))}
      </div>
      {required && !value && <ZorunluUyari />}
    </div>
  )
}

function formatDogumTr(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleDateString('tr-TR')
}

export default function KatilimciStep({ formData, onChange, onSearch, isLoading }) {
  const set = (field, value) => onChange(field, value)
  const bulundu = Boolean(formData.ad)
  const [ikametModalOpen, setIkametModalOpen] = useState(false)

  const saveIkametgah = (draft) => {
    const lokasyon = [draft.ilce, draft.il].filter(Boolean).join(' / ')
    onChange({
      ikametUlke: draft.ulke,
      ikametIl: draft.il,
      ikametIlce: draft.ilce,
      ikametAdres1: draft.adres1,
      ikametAdres2: draft.adres2,
      ikametAdres3: draft.adres3,
      ikametgah: lokasyon,
      ikametgahAdres: formatIkametgahOzet(draft),
    })
  }

  return (
    <div className="p-6 md:p-8 space-y-6">
      <section className="bg-slate-50 p-6 rounded-lg border border-slate-100">
        <h4 className="text-sm font-bold text-blue-900 mb-6 flex items-center gap-2">
          <Search size={16} /> Katılımcı Bilgileri Arama
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
          <UnderlineField label="TCKN/VKN/YKN" required>
            <input
              className="w-full border-b-2 border-slate-200 p-2 focus:border-blue-600 outline-none bg-transparent font-mono"
              placeholder="Zorunlu alan!"
              value={formData.tckn}
              onChange={(e) => set('tckn', e.target.value)}
            />
            {!formData.tckn.trim() && <ZorunluUyari />}
          </UnderlineField>
          <UnderlineField label="Doğum Tarihi" required>
            <input
              type="date"
              className="w-full border-b-2 border-slate-200 p-2 focus:border-blue-600 outline-none bg-transparent"
              value={formData.searchDogumTarihi}
              onChange={(e) => set('searchDogumTarihi', e.target.value)}
            />
            {!formData.searchDogumTarihi && <ZorunluUyari />}
          </UnderlineField>
          <button
            type="button"
            onClick={onSearch}
            disabled={isLoading}
            className="bg-blue-700 text-white px-6 py-2.5 rounded font-bold hover:bg-blue-800 transition flex items-center justify-center gap-2 disabled:opacity-60"
          >
            <Search size={16} /> Ara
          </button>
        </div>
        <div className="mt-6 max-w-md">
          <label className="text-xs font-bold text-slate-600 uppercase">Baba Adı</label>
          <input
            type="text"
            className="w-full border-b-2 border-slate-200 p-2 mt-1 focus:border-blue-600 outline-none bg-transparent"
            value={formData.babaAdi}
            onChange={(e) => set('babaAdi', e.target.value)}
          />
        </div>
      </section>

      {bulundu && (
        <div className="space-y-0 border border-slate-200 rounded-lg overflow-hidden bg-white shadow-sm">
          {/* ... backup snapshot content omitted for brevity ... */}
        </div>
      )}

      <IkametgahAdresModal
        open={ikametModalOpen}
        onClose={() => setIkametModalOpen(false)}
        initial={ikametgahFromForm(formData)}
        onSave={saveIkametgah}
      />
    </div>
  )
}
